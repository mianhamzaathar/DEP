// pages/Home.js
import React from 'react';

function Home() {
  return (
    <div>
      <h1>Welcome to Our E-commerce Store</h1>
      <p>Browse our products and find the best deals!</p>
    </div>
  );
}

export default Home;
