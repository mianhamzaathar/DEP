// pages/ProductListing.js
import React from 'react';

function ProductListing() {
  return (
    <div>
      <h1>Product Listing</h1>
      <p>Here are all our products.</p>
      {/* Add product listing logic here */}
    </div>
  );
}

export default ProductListing;
